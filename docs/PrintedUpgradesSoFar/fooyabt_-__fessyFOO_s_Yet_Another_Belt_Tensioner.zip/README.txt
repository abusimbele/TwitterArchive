                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2502801
fooyabt -  fessyFOO's Yet Another Belt Tensioner by fessyfoo is licensed under the Creative Commons - Attribution - Non-Commercial - Share Alike license.
http://creativecommons.org/licenses/by-nc-sa/3.0/

# Summary

__fooyabt -  fessyFOO's Yet Another Belt Tensioner__



Belt Tensioner for Tronxy X1  and other that use the v-slot extruded aluminum rails.

have STL's in a few sizes specified by their range of travel:  10mm, 15mm, and 20mm.   filenames vary by rNN where NN is the range of travel.  the nut is the same for all of them. 

15mm  one is probably sufficient.   I like the 10mm because I wanted things as small as possible. 

the puller and the case are designed to be printed upside down, no supports  the stl files should be that way already.


_caveat emptor_:  using this on the y axis of the tronxy x1, it still has a 4mm flange.  which keeps the bed from getting  all the way to the edge.  if you were using that 4mm you will miss them.   at some point I hope to redesign the part to handle that.  (adding slot for the wheel, assuming it still has enough support. )

see [youtube video](https://youtu.be/ETPS50TQDgw)  for demonstration.

openscad source is [available on github](https://github.com/fessyfoo/fooyabt-belt-tensioner)

# Print Settings

Printer: Tronxy X1
Rafts: No
Supports: No

# Post-Printing

after printing smooth out any rough bits.   then test fit all the bits.   thread the nut up and down until it runs smooth.    the channels in the puller are designed to be tight  so make sure to slide the puller in and out of the case.  if/when it gets stuck use the nut to pull it back out.   move it around till it moves freely. 

last, the fit for the v-slot extrusion is set very tight.  it may not feel like it fits at first.  I suggest test fitting it on an open beam somewhere.   (take the handle off the Tronxy X1, use top of Z axis. )   Note it's possible to tighten the pulley up too tight, pinching the arms together.  If this happens you also won't be able to fit the feet into the v-slot. 


# How I Designed This

![Alt text](https://cdn.thingiverse.com/assets/95/2d/42/3f/41/IMG_3104.jpg)
a lot of trial and error. ...  and openscad

![Alt text](https://cdn.thingiverse.com/assets/46/4c/f0/b4/0b/IMG_3103.jpg)