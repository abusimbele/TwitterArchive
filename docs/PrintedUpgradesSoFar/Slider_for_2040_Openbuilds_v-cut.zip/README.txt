                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:2275654
Slider for 2040 Openbuilds v-cut by FabianFriethjoph is licensed under the Creative Commons - Attribution - Non-Commercial license.
http://creativecommons.org/licenses/by-nc/3.0/

# Summary

After encountering serious wobble in the X beam of my TronXY X1, I thought I might need something akin to the bed tightener by PB2000 ( http://www.thingiverse.com/thing:2203872 ). However, this piece is designed to work on on 2020 openbuild V-Slot following the documentation ( http://www.thingiverse.com/thing:69333 ), and the Z-Axis of the TronXY X1 is made from a 2040. So, spacing couldn't be taken over.


The Version 0 test type took the measurements of Press Reset's brackets ( http://www.thingiverse.com/thing:2120675 ), but the spacing of the print was off. WAY off. I had to cut it up, using them as spacers to be screwed on. Back to field 1: start from scratch, grab the documentation.

Taking the measurements of the metal piece, the openbuilds documentation (measurements of the V-Slot beam and matching 23.9mm wheels), the ISO norms (M4 & M5 machine screws), I startet to design the piece from scratch with set goals in mind:
* the bend should leave space for the M4 screw that holds the actual X-Beam on the TronXY X1
* it should act as spacer just as much as tightener
* two pieces shall clamp it in position around the 2040 beam

After dissembly to check the measurements, I noticed that the wobble did not originate in a lack of tightening, but my failure: a single screw was not pulled tight enough.

5 Versions are available:
* 75% plastic thread - this variant is designed to carry a thread for M5 cut into it and has holes of 4.2 mm diameter. The part will act like connected nuts, keep this in mind in assembly, like when you want to clamp the beam between two!
* Close Fit - This variant is meant to leave no wriggle for the screws, but it does not bite down on them either. 5.25 mm diameter holes.
* Standard Fit - somewhat more loose, this is the diameter of the holes in the metal plate I took the original measurements from.
* 75% plastic thread and Standard fit on the two back holes with a hole to hold the 7.11mm cylinder of an Openbuild eccentric nut, allowing adjustment of the tightener

EDIT:
After encountering, that the walls of the threaded variant can bend a bit while cutting the thread, all variants were updated with thicker walls.

# How I Designed This

![Alt text](https://cdn.thingiverse.com/assets/ac/5e/1b/ee/14/orca-image-1492948084509.jpg_1492948084720%5B1.jpeg)
Version 0 with length estimations based on PressReset's X-plate. It ended up having to be cut apart, acting as screw on spacers

![Alt text](https://cdn.thingiverse.com/assets/91/12/19/cb/1b/Slider.png)
First Draft - avoiding the M4 screw that holds the X-Axis like this would have forced the bend to end inside the X-Axis stepper. => Discarded

![Alt text](https://cdn.thingiverse.com/assets/af/4e/72/79/28/Draft.png)
Side View of Iteration 1 - notice that the measurements here are off by 0.4mm in Z and XZ!

![Alt text](https://cdn.thingiverse.com/assets/6b/27/a6/73/33/Draft2.png)
Itteration 2: Avoiding the M4 screw head on the other side seemed like a better idea, yet still the measurements were off

![Alt text](https://cdn.thingiverse.com/assets/0b/6e/48/3e/81/Slider3.png)
Iteration 3 - Loose Fit Variant: After reconfirming all the measurements, the redesign of the piece was just a matter of drawing the pieces.

![Alt text](https://cdn.thingiverse.com/assets/8b/ec/b3/af/28/Slider_Views.png)
complete assembly plan, as found in the TronXY X1 - Pink: Acrylic plate; Not shown: Steel back plate.